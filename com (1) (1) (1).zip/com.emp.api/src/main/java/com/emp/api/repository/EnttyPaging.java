package com.emp.api.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.emp.api.entity.Entty;

public interface EnttyPaging  extends PagingAndSortingRepository<Entty,Integer>{

	

	
	}
