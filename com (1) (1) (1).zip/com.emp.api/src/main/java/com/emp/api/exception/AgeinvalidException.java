//package com.emp.api.exception;
//
//public class AgeinvalidException extends RuntimeException{
//
//	private String message ;
//
//	public AgeinvalidException(String message) {
//		super();
//		this.message = message;
//	}
//	
//	@Override
//	public String getMessage() {
//		return message; 
//	}
//}
