package com.emp.api.repository;

import org.springframework.data.repository.CrudRepository;

import com.emp.api.entity.ImageEntity;

public interface ImageRepository extends CrudRepository<ImageEntity,Long>{

}
