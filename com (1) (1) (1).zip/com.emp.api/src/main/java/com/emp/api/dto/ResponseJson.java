 package com.emp.api.dto;

 public class ResponseJson {
	
    private String designation; 
    private String hireDate;
    
    
    public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getHireDate() {
		return hireDate;
	}
	public void setHireDate(String hireDate) {
		this.hireDate = hireDate;
	} 
    
}
